//
//  RequestHandler.swift
//  WeatherForecast
//
//  Created by Amit Gajjar on 8/5/16.
//  Copyright © 2016 AmitGajjar. All rights reserved.
//

import UIKit
import Alamofire

class RequestHandler {
    
    //To Make singleton class
    static let sharedRequestHandler: RequestHandler = RequestHandler()
    private init() {
        
    }
    
    // MARK: - Internal Methods
    internal func requestJSON(baseURL: String, parameters: [String: String], completionHandler: (AnyObject?) -> ()) {
        Alamofire.request(.GET, baseURL, parameters: parameters)
            .responseJSON { response in
               completionHandler(response.result.value)
        }
    }
    
}
