//
//  RequestManager.swift
//  WeatherForecast
//
//  Created by Amit Gajjar on 8/5/16.
//  Copyright © 2016 AmitGajjar. All rights reserved.
//

import UIKit



class RequestManager {
    
    
    let requestHandler: RequestHandler = RequestHandler.sharedRequestHandler
    
    // MARK: - Internal Methods
    // Method to fetch data by City Name
    internal func requestTemperatureDetailsForCity(cityName: String, numberOfDays: Int, completionHandler: (String, AnyObject?) -> ()) {
        let parameterDictionary: [String: String] = self.parameterDictionaryForCityRequest(cityName, numberOfDays: numberOfDays)
        
        requestHandler.requestJSON(Constants.baseURL, parameters: parameterDictionary) { (responseJSON) in
            if let responseJSON = responseJSON {
                if let responseCode = responseJSON.valueForKey("cod") as? String {
                    switch responseCode {
                    case Constants.ResponseCode.CityNotFound.rawValue:
                        var responseMessage: String? = nil
                        if let message = responseJSON.valueForKey("message") as? String {
                            responseMessage = message
                        }
                        completionHandler(responseCode, responseMessage)
                    case Constants.ResponseCode.CityFound.rawValue:
                        if let cityNameResponse = responseJSON.valueForKey("city")?.valueForKey("name") as? String {
                            if cityName.lowercaseString == cityNameResponse.lowercaseString {
                                if let temparatureList = responseJSON.valueForKey("list") as? [AnyObject] {
                                    completionHandler(responseCode, temparatureList)
                                }
                            }
                            else {
                                completionHandler(Constants.ResponseCode.CityMisMatch.rawValue, responseJSON)
                            }
                        }
                    default:
                        completionHandler(responseCode, nil)
                    }
                }
            }
            else {
                completionHandler(Constants.ResponseCode.NoResponse.rawValue, nil)
            }
        }
    }
    
    // Method to fetch data by Current Location
    internal func requestTemperatureDetailsForCurrentLocation(latitude: String, longitude: String, numberOfDays: Int, completionHandler: (String, AnyObject?, String?) -> ()) {
        let parameterDictionary: [String: String] = self.parameterDictionaryForCurrentLocationRequest(latitude, longitude: longitude, numberOfDays: numberOfDays)
        
        requestHandler.requestJSON(Constants.baseURL, parameters: parameterDictionary) { (responseJSON) in
            if let responseJSON = responseJSON {
                if let responseCode = responseJSON.valueForKey("cod") as? String {
                    switch responseCode {
                    case Constants.ResponseCode.CityNotFound.rawValue:
                        var responseMessage: String? = nil
                        if let message = responseJSON.valueForKey("message") as? String {
                            responseMessage = message
                        }
                        completionHandler(responseCode, responseMessage, nil)
                    case Constants.ResponseCode.CityFound.rawValue:
                        if let temparatureList = responseJSON.valueForKey("list") as? [AnyObject] {
                            var cityName: String? = nil
                            if let city = responseJSON.valueForKey("city")?.valueForKey("name") as? String {
                                cityName = city
                            }
                            completionHandler(responseCode, temparatureList, cityName)
                        }
                    default:
                        completionHandler(responseCode, nil, nil)
                    }
                }
            }
            else {
                completionHandler(Constants.ResponseCode.NoResponse.rawValue, nil, nil)
            }
        }

    }
    
    // MARK: - Private Methods
    private func parameterDictionaryForCityRequest(cityName: String, numberOfDays: Int) -> [String: String] {
        var parameterDictionary: [String: String] = [:]
        parameterDictionary[Constants.ParameterList.CityName.rawValue] = cityName
        parameterDictionary[Constants.ParameterList.NumberOfDays.rawValue] = String(numberOfDays)
        parameterDictionary[Constants.ParameterList.AppID.rawValue] = Constants.apiKey
        parameterDictionary[Constants.ParameterList.Units.rawValue] = Constants.TemperatureUnits.Celcius.rawValue
        return parameterDictionary
    }
    
    private func parameterDictionaryForCurrentLocationRequest(latitude: String, longitude: String, numberOfDays: Int) -> [String: String] {
        var parameterDictionary: [String: String] = [:]
        parameterDictionary[Constants.ParameterList.Latitude.rawValue] = latitude
        parameterDictionary[Constants.ParameterList.Longitude.rawValue] = longitude
        parameterDictionary[Constants.ParameterList.NumberOfDays.rawValue] = String(numberOfDays)
        parameterDictionary[Constants.ParameterList.AppID.rawValue] = Constants.apiKey
        parameterDictionary[Constants.ParameterList.Units.rawValue] = Constants.TemperatureUnits.Celcius.rawValue
        return parameterDictionary
    }
    
}
