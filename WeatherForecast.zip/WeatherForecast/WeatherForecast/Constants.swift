//
//  Constants.swift
//  WeatherForecast
//
//  Created by Amit Gajjar on 8/11/16.
//  Copyright © 2016 AmitGajjar. All rights reserved.
//

class Constants {
    enum ResponseCode: String {
        case CityNotFound = "404"
        case CityFound = "200"
        case NoResponse = "-1"
        case CityMisMatch = "0"
    }
    
    enum TemperatureUnits: String {
        case Celcius = "metric"
        case Fahrenheit = "imperial"
    }
    
    enum ParameterList: String {
        case CityName = "q"
        case Latitude = "lat"
        case Longitude = "lon"
        case NumberOfDays = "cnt"
        case AppID = "APPID"
        case Units = "units"
    }
    
    enum SegueIdentifier: String {
        case WeatherViewController = "enterCityWeatherVC"
    }
    
    enum CellIdentifier: String {
        case EnterCityTableCellIdentifier = "enterCityTableCell"
        case WeatherTableCellIdentifier = "weatherTableCell"
    }
    
    //MARK: - Common Constants
    static let okText = "Ok"
    static let emptyText = ""
    
    //MARK: - UIAlertControllerConstants
    //MARK: Titles
    static let alreadyExistTitle = "Already Exist"
    static let enterCityTitle = "Enter City"
    static let weather365Title = "Weather 365"
    static let weather365LocationSettingsTitle = "Weather 365 Location Settings"
    static let weather365LocationErrorTitle = "Weather 365 Location Error"
    
    //MARK: Messages
    static let alreadyExistMessage = "City already exist in below list"
    static let enterCityMessage = "Please enter city name"
    static let cityNotFoundMessage = "City not found"
    static let errorOnServerSideMessage = "Error on server side"
    static let weather365LocationSettingsMessage = "To use Location Service, Turn on from device settings."
    static let weather365LocationErrorMessage = "Current Location not found. Try again later."
    
    //MARK: - RequestManager Class Constants
    static let baseURL = "http://api.openweathermap.org/data/2.5/forecast/daily"
    static let apiKey = "bca4dd216f067220a3a5c2c3e6a68542"
    
    //MARK: - WeatherTableViewCell Constants
    static let baseImageURL: String = "http://openweathermap.org/img/w/"
    static let maxTemperatureLabelText = "\u{2191}"
    static let minTemperatureLabelText = "\u{2193}"
    static let degreeText = "\u{00B0}"
    static let notApplicableText = "NA"
    static let cloudsLabelText = "Clouds"
    static let windSpeedLabelText = "Wind Speed"
    static let humidityLabelText = "Humidity"
    static let pressureLabelText = "Pressure"
    static let rainLabelText = "Rain"
    static let imageFileFormatText = ".png"
}
