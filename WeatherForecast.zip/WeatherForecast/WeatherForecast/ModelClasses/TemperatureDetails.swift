//
//  TemperatureDetails.swift
//  WeatherForecast
//
//  Created by Amit Gajjar on 8/8/16.
//  Copyright © 2016 AmitGajjar. All rights reserved.
//

import UIKit

class TemperatureDetails {

    var dayTemperature: Double
    var morningTemperature: Double
    var eveningTemperature: Double
    var nightTemperature: Double
    var minTemperature: Double
    var maxTemperature: Double
    
    init(dayTemp: Double, morningTemp: Double, eveningTemp: Double, nightTemp: Double, minTemp: Double, maxTemp: Double) {
        self.dayTemperature = dayTemp
        self.morningTemperature = morningTemp
        self.eveningTemperature = eveningTemp
        self.nightTemperature = nightTemp
        self.minTemperature = minTemp
        self.maxTemperature = maxTemp
    }
}
