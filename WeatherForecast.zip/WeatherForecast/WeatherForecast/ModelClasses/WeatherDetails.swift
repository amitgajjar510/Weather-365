//
//  WeatherDetails.swift
//  WeatherForecast
//
//  Created by Amit Gajjar on 8/8/16.
//  Copyright © 2016 AmitGajjar. All rights reserved.
//

import UIKit

class WeatherDetails {

    var temperatureDetails: TemperatureDetails?
    
    var dateTemperatureCaptured: Int
    var atmosphericPressure: Double
    var humidity: Int
    var windSpeed: Float
    var windDirection: Int
    var clouds: Int
    
    var rain: Float?
    var mainWeatherDetail: String?
    var descriptionWeatherDetail: String?
    var iconWeatherDetail: String?
    
    var isExpanded: Bool = false
    
    init(tempDetails: TemperatureDetails?, dateTempCaptured: Int, pressure: Double, humidityPercentage: Int, wind: Float, windDir: Int, cloudsPercentage: Int) {
        temperatureDetails = tempDetails
        dateTemperatureCaptured = dateTempCaptured
        atmosphericPressure = pressure
        humidity = humidityPercentage
        windSpeed = wind
        windDirection = windDir
        clouds = cloudsPercentage
    }
}
