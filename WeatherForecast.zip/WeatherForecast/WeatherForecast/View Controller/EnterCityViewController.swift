//
//  EnterCityViewController.swift
//  WeatherForecast
//
//  Created by Amit Gajjar on 8/4/16.
//  Copyright © 2016 AmitGajjar. All rights reserved.
//

import UIKit

class EnterCityViewController: UIViewController {

    // MARK: - Properties & Outlets
    var arrayOfCities: [String] = []
    var tapGestureForKeyboard: UITapGestureRecognizer? = nil
    
    @IBOutlet weak var enterCityTableView: UITableView!
    @IBOutlet weak var enterCityTextField: UITextField!
    
    
    // MARK: - View Methods
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - Action Methods
    @IBAction func addCityClick(sender: UIButton) {
        guard let cityName = enterCityTextField.text?.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
            else {
                return
        }
        if cityName != "" {
            if self.checkCityAlreadyExist(cityName) == false {
                arrayOfCities.append(cityName)
                enterCityTableView.reloadData()
            }
            else {
                self.presentAlertController(Constants.alreadyExistTitle, alertMessage: Constants.alreadyExistMessage)
            }
        }
        else {
            self.presentAlertController(Constants.enterCityTitle, alertMessage: Constants.enterCityMessage)
        }
        enterCityTextField.text = Constants.emptyText
    }
    
    @IBAction func currentLocationClick(sender: UIBarButtonItem) {
        self.performSegueWithIdentifier(Constants.SegueIdentifier.WeatherViewController.rawValue, sender: nil)
    }
    
    
    @IBAction func cityNameDidBeginEditing(sender: UITextField) {
        self.tapGestureForKeyboard = UITapGestureRecognizer(target: self, action: #selector(EnterCityViewController.dismissKeyboard))
        self.view.addGestureRecognizer(self.tapGestureForKeyboard!)
    }
    
    @IBAction func cityNameDidEndEditing(sender: UITextField) {
        if self.tapGestureForKeyboard != nil {
            self.view.removeGestureRecognizer(self.tapGestureForKeyboard!)
        }
    }
    
   
    // MARK: - Navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == Constants.SegueIdentifier.WeatherViewController.rawValue {
            if let weatherViewController = segue.destinationViewController as? WeatherViewController {
                weatherViewController.cityName = sender as? String
            }
        }
    }
    
    // MARK: - Private Methods
    private func checkCityAlreadyExist(cityName: String) -> Bool {
        var exist = false
        for city in arrayOfCities {
            if cityName.lowercaseString == city.lowercaseString {
                exist = true
                break
            }
        }
        return exist
    }
    
    //Method to present UIAlertController
    private func presentAlertController(alertTitle: String?, alertMessage: String?) {
        let alertController = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        let okAction = UIAlertAction(title: Constants.okText, style: .Default, handler: { (okAction) in
            self.dismissViewControllerAnimated(true, completion: nil)
        })
        alertController.addAction(okAction)
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    // MARK: - Gesture Selector Methods
    func dismissKeyboard() {
        enterCityTextField.resignFirstResponder()
    }
}

//MARK: - Extension for TableView Methods
extension EnterCityViewController: UITableViewDataSource, UITableViewDelegate  {
    
    // MARK: UITableViewDataSource Methods
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCities.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let enterCityTableCell = tableView.dequeueReusableCellWithIdentifier(Constants.CellIdentifier.EnterCityTableCellIdentifier.rawValue, forIndexPath: indexPath)
        enterCityTableCell.textLabel?.text = arrayOfCities[indexPath.row]
        return enterCityTableCell
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == UITableViewCellEditingStyle.Delete {
            arrayOfCities.removeAtIndex(indexPath.row)
            enterCityTableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Top)
        }
    }
    
    // MARK: UITableViewDelegate Methods
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let cityName = arrayOfCities[indexPath.row]
        self.performSegueWithIdentifier(Constants.SegueIdentifier.WeatherViewController.rawValue, sender: cityName)
    }
}
