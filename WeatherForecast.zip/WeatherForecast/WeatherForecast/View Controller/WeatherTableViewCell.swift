//
//  WeatherTableViewCell.swift
//  WeatherForecast
//
//  Created by Amit Gajjar on 8/8/16.
//  Copyright © 2016 AmitGajjar. All rights reserved.
//

import UIKit

class WeatherTableViewCell: UITableViewCell {
    
    static let docDirPath: String = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0]
    
    @IBOutlet weak var weatherDateLabel: UILabel!
    @IBOutlet weak var weatherDescriptionLabel: UILabel!
    @IBOutlet weak var weatherImageView: UIImageView!
    @IBOutlet weak var rainLabel: UILabel!
    @IBOutlet weak var cloudsLabel: UILabel!
    @IBOutlet weak var windSpeedLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var pressureLabel: UILabel!
    
    @IBOutlet weak var maxTemperatureLabel: UILabel!
    @IBOutlet weak var minTemperatureLabel: UILabel!
    @IBOutlet weak var dayTemperatureLabel: UILabel!
    @IBOutlet weak var morningTemperatureLabel: UILabel!
    @IBOutlet weak var eveningTemperatureLabel: UILabel!
    @IBOutlet weak var nightTemperatureLabel: UILabel!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // MARK: - Internal Methods
    internal func fillCellData(weatherDetails: WeatherDetails) {
        let dateInNumber: NSNumber = weatherDetails.dateTemperatureCaptured
        let dateTimeInWords = dateInNumber.dateTimeInWords
        weatherDateLabel.text = "\(dateTimeInWords.1), \(dateTimeInWords.0)"

        weatherDescriptionLabel.text = weatherDetails.descriptionWeatherDetail
        maxTemperatureLabel.text = Constants.maxTemperatureLabelText
        minTemperatureLabel.text = Constants.minTemperatureLabelText
        if let temperatureDetail = weatherDetails.temperatureDetails {
            maxTemperatureLabel.text = "\(maxTemperatureLabel.text!) \(temperatureDetail.maxTemperature)\(Constants.degreeText)c"
            minTemperatureLabel.text = "\(minTemperatureLabel.text!) \(temperatureDetail.minTemperature)\(Constants.degreeText)c"
            if weatherDetails.isExpanded {
                dayTemperatureLabel.text = "D \(temperatureDetail.dayTemperature)\(Constants.degreeText)c"
                morningTemperatureLabel.text = "M \(temperatureDetail.morningTemperature)\(Constants.degreeText)c"
                eveningTemperatureLabel.text = "E \(temperatureDetail.eveningTemperature)\(Constants.degreeText)c"
                nightTemperatureLabel.text = "N \(temperatureDetail.nightTemperature)\(Constants.degreeText)c"
            }
            else {
                dayTemperatureLabel.text = Constants.emptyText
                morningTemperatureLabel.text = Constants.emptyText
                eveningTemperatureLabel.text = Constants.emptyText
                nightTemperatureLabel.text = Constants.emptyText
            }
        }
        else {
            maxTemperatureLabel.text = "\(maxTemperatureLabel.text!) \(Constants.notApplicableText)"
            minTemperatureLabel.text = "\(minTemperatureLabel.text!) \(Constants.notApplicableText)"
        }
        
        if weatherDetails.isExpanded {
            cloudsLabel.text = "\(Constants.cloudsLabelText): \(weatherDetails.clouds)%"
            windSpeedLabel.text = "\(Constants.windSpeedLabelText): \(weatherDetails.windSpeed)"
            humidityLabel.text = "\(Constants.humidityLabelText): \(weatherDetails.humidity)%"
            pressureLabel.text = "\(Constants.pressureLabelText): \(weatherDetails.atmosphericPressure)"
            if let rainPercentage = weatherDetails.rain {
                rainLabel.text = "\(Constants.rainLabelText): \(Int(rainPercentage))%"
            }
            else {
                rainLabel.text = Constants.emptyText
            }
        }
        else {
            windSpeedLabel.text = Constants.emptyText
            cloudsLabel.text = Constants.emptyText
            humidityLabel.text = Constants.emptyText
            pressureLabel.text = Constants.emptyText
            if let rainPercentage = weatherDetails.rain {
                rainLabel.text = "\(Int(rainPercentage))%"
            }
            else {
                rainLabel.text = Constants.emptyText
            }
        }
    
        if let imageName = weatherDetails.iconWeatherDetail {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { 
                let weatherImage = self.weatherImage(imageName)
                dispatch_async(dispatch_get_main_queue(), { 
                    self.weatherImageView.image = weatherImage
                })
            })
        }
    }
    
    // MARK: - Private Methods
    private func weatherImage(imageName: String) -> UIImage? {
        var image: UIImage? = nil
        image = self.loadImageFromDocDir(imageName)
        if image == nil {
            if let imageURL = NSURL(string: "\(Constants.baseImageURL)\(imageName)\(Constants.imageFileFormatText)") {
                if let imageData: NSData = NSData(contentsOfURL: imageURL) {
                    image = UIImage(data: imageData)
                    self.saveImageToDocDir(imageName, imageData: imageData)
                }
            }
        }
        return image
    }
    
    private func saveImageToDocDir(imageName: String, imageData: NSData) {
        let imagePath = WeatherTableViewCell.docDirPath + "/\(imageName)\(Constants.imageFileFormatText)"
        imageData.writeToFile(imagePath, atomically: true)
    }
    
    private func loadImageFromDocDir(imageName: String) -> UIImage? {
        let imagePath = WeatherTableViewCell.docDirPath + "/\(imageName)\(Constants.imageFileFormatText)"
        return UIImage(contentsOfFile: imagePath)
    }
}
