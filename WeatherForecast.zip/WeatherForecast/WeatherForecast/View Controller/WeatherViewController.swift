//
//  WeatherViewController.swift
//  WeatherForecast
//
//  Created by Amit Gajjar on 8/4/16.
//  Copyright © 2016 AmitGajjar. All rights reserved.
//

import UIKit
import CoreLocation

class WeatherViewController: UIViewController {

    // MARK: - Properties & Outlets
    var cityName: String? = nil
    var currentLocation: CLLocation? = nil
    var locationManager: CLLocationManager = CLLocationManager()
    var arrayOfWeatherDays: [WeatherDetails] = []
    let requestManager: RequestManager = RequestManager()
    var activityIndicator: UIActivityIndicatorView? = nil
    
    @IBOutlet weak var weatherTableView: UITableView!
    
    // MARK: - View Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = cityName
        self.activityIndicatorView()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        if let cityName = cityName {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
                self.fetchWeatherDataForCity(cityName)
            }
        }
        else {
            self.getCurrentLocation()
        }
    }
 
    // MARK: - Private Methods
    private func fetchWeatherDataForCity(cityName: String) {
        requestManager.requestTemperatureDetailsForCity(cityName, numberOfDays: 14) { (responseCode, response) in
            self.checkForErrorAndParse(responseCode, response: response)
        }
    }
    
    private func fetchWeatherDataForCurrentLocation(currentLocation: CLLocation) {
        requestManager.requestTemperatureDetailsForCurrentLocation(String(currentLocation.coordinate.latitude), longitude: String(currentLocation.coordinate.longitude), numberOfDays: 14) { (responseCode, response, cityName) in
            self.checkForErrorAndParse(responseCode, response: response, cityName: cityName)
        }
    }
    
    private func checkForErrorAndParse(responseCode: String, response: AnyObject?, cityName: String? = nil) {
        let titleText: String = Constants.weather365Title
        var messageText: String = Constants.emptyText
        let alertActionText = Constants.okText
        if let response = response {
            switch responseCode {
            case Constants.ResponseCode.CityFound.rawValue:
                self.parseJSONResponse(response)
            case Constants.ResponseCode.CityNotFound.rawValue:
                messageText = Constants.cityNotFoundMessage
            case Constants.ResponseCode.CityMisMatch.rawValue:
                messageText = Constants.cityNotFoundMessage
            default:
                messageText = Constants.errorOnServerSideMessage
            }
        }
        else {
            messageText = Constants.errorOnServerSideMessage
        }
        
        dispatch_async(dispatch_get_main_queue()) {
            if messageText != Constants.emptyText {
                self.presentAlertController(titleText, alertMessage: messageText, alertAction: alertActionText)
            }
            if let cityName = cityName {
                self.navigationItem.title = cityName
            }
            self.weatherTableView.reloadData()
            if self.activityIndicator != nil {
                self.activityIndicator?.stopAnimating()
            }
        }
    }
    
    
    private func parseJSONResponse(response: AnyObject) {
        if let responseArray = response as? [AnyObject] {
            for weatherDetail in responseArray {
                if let weatherDetail = self.weatherDetail(weatherDetail) {
                    arrayOfWeatherDays.append(weatherDetail)
                }
            }
        }
    }
    
    private func weatherDetail(weatherDetail: AnyObject?) -> WeatherDetails? {
        var weatherDetailObject: WeatherDetails? = nil
        if let weatherDetail = weatherDetail as? [String: AnyObject] {
            let temperatureDetail: TemperatureDetails? = self.temperatureDetail(weatherDetail["temp"])
            if let dateTempCaptured = weatherDetail["dt"] as? Int, pressure = weatherDetail["pressure"] as? Double, humidity = weatherDetail["humidity"] as? Int, wind = weatherDetail["speed"] as? Float, windDir = weatherDetail["deg"] as? Int, clouds = weatherDetail["clouds"] as? Int {
                weatherDetailObject = WeatherDetails(tempDetails: temperatureDetail, dateTempCaptured: dateTempCaptured, pressure: pressure, humidityPercentage: humidity, wind: wind, windDir: windDir, cloudsPercentage: clouds)
                if let rainPercentage = weatherDetail["rain"] as? Float {
                    weatherDetailObject?.rain = rainPercentage
                }
                if let weatherArray = weatherDetail["weather"] as? [AnyObject] {
                    if let lastWeatherObject = weatherArray.last as? [String: AnyObject] {
                        if let mainWeatherDetail = lastWeatherObject["main"] as? String, descriptionWeatherDetail = lastWeatherObject["description"] as? String, icon = lastWeatherObject["icon"] as? String {
                            weatherDetailObject?.mainWeatherDetail = mainWeatherDetail
                            weatherDetailObject?.descriptionWeatherDetail = descriptionWeatherDetail
                            weatherDetailObject?.iconWeatherDetail = icon
                        }
                    }
                }
            }
        }
        return weatherDetailObject
    }
    
    private func temperatureDetail(tempDetail: AnyObject?) -> TemperatureDetails? {
        var temperatureDetail: TemperatureDetails? = nil
        if let tempDetail = tempDetail as? [String: Double] {
            if let dayTemp = tempDetail["day"], morningTemp = tempDetail["morn"], eveningTemp = tempDetail["eve"], nightTemp = tempDetail["night"], minTemp = tempDetail["min"], maxTemp = tempDetail["max"] {
                temperatureDetail = TemperatureDetails(dayTemp: dayTemp, morningTemp: morningTemp, eveningTemp: eveningTemp, nightTemp: nightTemp, minTemp: minTemp, maxTemp: maxTemp)
            }
        }
        return temperatureDetail
    }
    
    //Method to present UIAlertController
    private func presentAlertController(alertTitle: String?, alertMessage: String?, alertAction: String?) {
        let alertController = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        if alertAction != nil {
            let okAction = UIAlertAction(title: alertAction, style: .Default, handler: { (okAction) in
                self.dismissViewControllerAnimated(true, completion: nil)
            })
            alertController.addAction(okAction)
        }
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    //Method to present UIActivityIndicatorView
    private func activityIndicatorView() {
        let activityIndicatorFrame = CGRectMake(self.view.frame.size.width/2 - 25, self.view.frame.size.height/2 - 50, 50, 50)
        self.activityIndicator = UIActivityIndicatorView(frame: activityIndicatorFrame)
        self.activityIndicator?.hidesWhenStopped = true
        self.activityIndicator?.activityIndicatorViewStyle = .Gray
        self.activityIndicator?.startAnimating()
        self.weatherTableView.addSubview(activityIndicator!)
    }
    
    // MARK: Location Manager Methods
    private func getCurrentLocation() {
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.distanceFilter = kCLDistanceFilterNone;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        if (UIDevice.currentDevice().systemVersion as NSString).floatValue >= 8.0 {
            if CLLocationManager.locationServicesEnabled() {
                if CLLocationManager.authorizationStatus() == .NotDetermined {
                    locationManager.requestWhenInUseAuthorization()
                } else if CLLocationManager.authorizationStatus() == .Restricted || CLLocationManager.authorizationStatus() == .Denied {
                    self.presentAlertController(Constants.weather365LocationSettingsTitle, alertMessage: Constants.weather365LocationSettingsMessage, alertAction: Constants.okText)
                } else if CLLocationManager.authorizationStatus() == .AuthorizedWhenInUse {
                    locationManager.startUpdatingLocation()
                } else if CLLocationManager.authorizationStatus() == .AuthorizedAlways {
                    locationManager.startUpdatingLocation()
                }
            }
            else {
                self.presentAlertController(Constants.weather365LocationSettingsTitle, alertMessage: Constants.weather365LocationSettingsMessage, alertAction: Constants.okText)
            }
        }
        else {
            locationManager.startUpdatingLocation()
        }
    }
}

// MARK: - UITableViewDataSource & UITableViewDelegate Methods
extension WeatherViewController: UITableViewDataSource, UITableViewDelegate {
    
    // MARK: UITableViewDataSource Methods
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfWeatherDays.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let weatherCell = tableView.dequeueReusableCellWithIdentifier(Constants.CellIdentifier.WeatherTableCellIdentifier.rawValue, forIndexPath: indexPath) as? WeatherTableViewCell
        if weatherCell != nil {
            weatherCell?.fillCellData(arrayOfWeatherDays[indexPath.row])
        }
        return weatherCell!
    }
    
    // MARK: UITableViewDelegate Methods
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        CATransaction.begin()
        self.weatherTableView.beginUpdates()

        arrayOfWeatherDays[indexPath.row].isExpanded = !arrayOfWeatherDays[indexPath.row].isExpanded
        if arrayOfWeatherDays[indexPath.row].isExpanded {
            tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
        }

        CATransaction.setCompletionBlock {
            if !self.arrayOfWeatherDays[indexPath.row].isExpanded {
                tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
            }
        }
        self.weatherTableView.endUpdates()
        CATransaction.commit()
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if arrayOfWeatherDays[indexPath.row].isExpanded {
            return 137.0
        }
        return 67.0
    }
    
    
}
// MARK: - CLLocationManagerDelegate Methods
extension WeatherViewController:  CLLocationManagerDelegate {
    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        self.presentAlertController(Constants.weather365LocationErrorTitle, alertMessage: Constants.weather365LocationErrorMessage, alertAction: Constants.okText)
        locationManager.stopUpdatingLocation()
    }
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let newLocation: CLLocation = locations.last {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
                self.fetchWeatherDataForCurrentLocation(newLocation)
            }
        }
        else {
            self.presentAlertController(Constants.weather365LocationErrorTitle, alertMessage: Constants.weather365LocationErrorMessage, alertAction: Constants.okText)
        }
        locationManager.stopUpdatingLocation()
    }
    
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        switch status {
        case CLAuthorizationStatus.AuthorizedWhenInUse:
            locationManager.startUpdatingLocation()
        case CLAuthorizationStatus.AuthorizedAlways:
            locationManager.startUpdatingLocation()
        case CLAuthorizationStatus.NotDetermined:
            break
        default:
            break
        }
    }
    
}
