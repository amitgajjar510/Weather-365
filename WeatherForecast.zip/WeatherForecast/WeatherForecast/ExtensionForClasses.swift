//
//  ExtensionForClasses.swift
//  WeatherForecast
//
//  Created by Amit Gajjar on 8/9/16.
//  Copyright © 2016 AmitGajjar. All rights reserved.
//

import UIKit

enum FormattedDate: String {
    case Today = "Today"
    case Tomorrow = "Tomorrow"
}

// MARK: - Extension for NSDate to get time in milliseconds
extension NSDate {
    
    var timeInMillis: NSNumber {
        get {
            let uint64Format = UInt64(self.timeIntervalSince1970)
            return NSNumber(unsignedLongLong: uint64Format)
        }
    }
    
    var midnightDateTime: NSDate {
        let cal: NSCalendar = NSCalendar.currentCalendar()
        let newDate: NSDate = cal.dateBySettingHour(0, minute: 0, second: 0, ofDate: self, options: NSCalendarOptions())!
        return newDate
    }
}

// MARK: - Extension for NSNumber to get timeSince1970 in seconds
extension NSNumber {
    
    var timeIntervalSince1970InSeconds: NSTimeInterval {
        get {
            return NSTimeInterval(self.integerValue)
        }
    }
    
    private func dateFormatter() -> NSDateFormatter {
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "MMM dd, yyyy, HH:mm a, EEEE"
        return dateFormatter
    }
    
    var dateTimeInWords: (String, String) {
        get {
            let daysCount = calculateDaysBetween(NSDate().timeInMillis, endDate: self)
            let dateFormatted = dateFormatter().stringFromDate(NSDate(timeIntervalSince1970:self.timeIntervalSince1970InSeconds))
            let dateArray = dateFormatted.characters.split{$0 == ","}.map(String.init)
            let day = dateArray[3].stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
            
            switch(daysCount) {
            case 0:
                return ("\(dateArray[0])", FormattedDate.Today.rawValue)
            case -1:
                return ("\(dateArray[0])", FormattedDate.Tomorrow.rawValue)
            default :
                return ("\(dateArray[0])", "\(day)")
            }
        }
    }
    
    private func calculateDaysBetween(startDate: NSNumber, endDate: NSNumber) -> Int {
        let calendar = NSCalendar.currentCalendar()
        var firstDate = NSDate(timeIntervalSince1970: startDate.timeIntervalSince1970InSeconds)
        var secondDate = NSDate(timeIntervalSince1970: endDate.timeIntervalSince1970InSeconds)
        
        firstDate = firstDate.midnightDateTime
        secondDate = secondDate.midnightDateTime
        
        let unitFlags = NSCalendarUnit.Day
        let components = calendar.components(unitFlags, fromDate: secondDate, toDate: firstDate, options: NSCalendarOptions.MatchStrictly)
        return (components.day)
    }
}

